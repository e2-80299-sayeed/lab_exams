int add(int,int);
int sub(int,int);
float div(int,int);
int multi(int,int);

int add(int op1, int op2)
{
	return op1 + op2;
}

int sub(int op1, int op2)
{
	return op1 - op2;
}

float div(int op1, int op2)
{
	return op1/op2;
}

int multi(int op1, int op2)
{
	return op1 * op2;
}
